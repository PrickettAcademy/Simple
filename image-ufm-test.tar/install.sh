"echo 'INSTALLING :)'" 
